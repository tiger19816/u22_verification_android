package hal.u22.works.team.b.verification4;


import java.io.File;
import java.io.IOException;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.app.Activity;

public class ImageDisplayActivity extends AppCompatActivity {

    //方向格納
    int orientation;

    private String mediaFile = CameraStartActivity.mediaFile.toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_display);

        TextView tvLatLong = findViewById(R.id.tvLatLong);
        ImageView ivImage = findViewById(R.id.ivImage);

        Intent intent = getIntent();
        mediaFile = getIntent().getExtras().getString("file");

        try {
            //Exifinterfaceのインスタンス取得
           // ExifInterface exif = new ExifInterface(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + "/Camera/2018_7_15_19_19_17_613.jpg");
            ExifInterface exif = new ExifInterface(mediaFile);
            Log.e("保存場所", mediaFile);

            //画像情報取得
            if(exif != null) {

                //方向
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_UNDEFINED);
                int rotation;
                switch (orientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90:
                    case ExifInterface.ORIENTATION_TRANSPOSE:
                        rotation = 90;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_180:
                    case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                        rotation = 180;
                        break;
                    case ExifInterface.ORIENTATION_ROTATE_270:
                    case ExifInterface.ORIENTATION_TRANSVERSE:
                        rotation = 270;
                        break;
                    default:
                        rotation = 0;
                }
                Matrix transformMatrix = new Matrix();
                transformMatrix.setRotate(rotation);

                //位置情報取得
                float[] latLong = new float[2];
                exif.getLatLong(latLong);
                String info = String.format("%f,%f", latLong[0],latLong[1]);
                tvLatLong.setText(info);
                Log.d("位置情報"  , info);

                //サムネイル
                if(exif.hasThumbnail()) {
                    byte[] image = exif.getThumbnail();
                    Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                    Bitmap converted = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), transformMatrix, true);
                    ivImage.setImageBitmap(converted);
                }
            }
        }
        catch (Exception e) {
            Log.e("例外", e.toString());
        }
    }
}
