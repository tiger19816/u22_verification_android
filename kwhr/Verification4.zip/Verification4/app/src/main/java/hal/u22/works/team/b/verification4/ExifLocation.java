package hal.u22.works.team.b.verification4;

import android.location.Location;

public class ExifLocation {
    private String longitudeRef;
    private String longitude;
    private String latitudeRef;
    private String latitude;

    public String getLongitudeRef() {
        return longitudeRef;
    }

    public void setLongitudeRef(String longitudeRef) {
        this.longitudeRef = longitudeRef;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitudeRef() {
        return latitudeRef;
    }

    public void setLatitudeRef(String latitudeRef) {
        this.latitudeRef = latitudeRef;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }


    /**
     * Exif形式にGPS Locationを変換して返す。
     * longitudeRef => W or E
     * latitudeRef => N or S
     * latitude and longitude => num1/denom1,num2/denom2,num3/denom3
     * ex) 12/1,34/1,56789/1000
     *
     * @param location
     * @return ExifLocation
     */
    public static ExifLocation encodeGpsToExifFormat(Location location) {
        ExifLocation exifLocation = new ExifLocation();
        // 経度の変換(正->東, 負->西)
        // convertの出力サンプル => 73:9:57.03876
        String[] lonDMS = Location.convert(location.getLongitude(), Location.FORMAT_SECONDS).split(":");
        StringBuilder lon = new StringBuilder();
        // 経度の正負でREFの値を設定（経度からは符号を取り除く）
        if (lonDMS[0].contains("-")) {
            exifLocation.setLongitudeRef("W");
        } else {
            exifLocation.setLongitudeRef("E");
        }
        lon.append(lonDMS[0].replace("-", ""));
        lon.append("/1,");
        lon.append(lonDMS[1]);
        lon.append("/1,");
        // 秒は小数の桁を数えて精度を求める
        int index = lonDMS[2].indexOf('.');
        if (index == -1) {
            lon.append(lonDMS[2]);
            lon.append("/1");
        } else {
            int digit = lonDMS[2].substring(index + 1).length();
            int second = (int) (Double.parseDouble(lonDMS[2]) * Math.pow(10, digit));
            lon.append(String.valueOf(second));
            lon.append("/1");
            for (int i = 0; i < digit; i++) {
                lon.append("0");
            }
        }
        exifLocation.setLongitude(lon.toString());

        // 緯度の変換(正->北, 負->南)
        // convertの出力サンプル => 73:9:57.03876
        String[] latDMS = Location.convert(location.getLatitude(), Location.FORMAT_SECONDS).split(":");
        StringBuilder lat = new StringBuilder();
        // 経度の正負でREFの値を設定（経度からは符号を取り除く）
        if (latDMS[0].contains("-")) {
            exifLocation.setLatitudeRef("S");
        } else {
            exifLocation.setLatitudeRef("N");
        }
        lat.append(latDMS[0].replace("-", ""));
        lat.append("/1,");
        lat.append(latDMS[1]);
        lat.append("/1,");
        // 秒は小数の桁を数えて精度を求める
        index = latDMS[2].indexOf('.');
        if (index == -1) {
            lat.append(latDMS[2]);
            lat.append("/1");
        } else {
            int digit = latDMS[2].substring(index + 1).length();
            int second = (int) (Double.parseDouble(latDMS[2]) * Math.pow(10, digit));
            lat.append(String.valueOf(second));
            lat.append("/1");
            for (int i = 0; i < digit; i++) {
                lat.append("0");
            }
        }
        exifLocation.setLatitude(lat.toString());

        return exifLocation;
    }
}


